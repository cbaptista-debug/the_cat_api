package com.faculdade.trabalho.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/*Defini��o dos atributos */

@Entity
@Table(name = "breed")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Breed {
	@Id	
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer idBreedPK;
	
	private String id;
	private String name;
	private String origin;
	private String temperament;	
	@Column(columnDefinition = "LONGTEXT")
	private String description;
	

	@OneToMany(
	        cascade = CascadeType.ALL,
	        orphanRemoval = true
	    )
	private List<Photo> photo = new ArrayList<Photo>();
	
	

	public List<Photo> getPhoto() {
		return photo;
	}
	public void setPhoto(List<Photo> photo) {
		this.photo = photo;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getTemperament() {
		return temperament;
	}
	public void setTemperament(String temperament) {
		this.temperament = temperament;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Integer getIdBreedPK() {
		return idBreedPK;
	}
	public void setIdBreedPK(Integer idBreedPK) {
		this.idBreedPK = idBreedPK;
	}

	

}
