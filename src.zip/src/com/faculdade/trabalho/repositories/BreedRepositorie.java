package com.faculdade.trabalho.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.faculdade.trabalho.entities.Breed;

@Repository
public interface BreedRepositorie extends JpaRepository<Breed, Integer>{
	
	@Query(value ="select b.name from BREED as b", nativeQuery = true)
	List<String> listBreedNames();
	
	@Query(value ="select b.name from BREED as b where b.temperament like %?1%", nativeQuery = true)
	List<String> listBreedNamesByTemperament(String temperament);
	
	@Query(value ="select b.name from BREED as b where b.origin like %?1%", nativeQuery = true)
	List<String> listBreedNamesByOrigin(String origin);

}
