package com.faculdade.trabalho.utils;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.faculdade.trabalho.entities.Breed;
import com.faculdade.trabalho.repositories.BreedPhotoRepositorie;
import com.faculdade.trabalho.repositories.BreedRepositorie;
import com.faculdade.trabalho.repositories.CategorieRepositorie;

@Component
public class DataBaseLoader {

	@Autowired
	CatApiProcessor processor;
	
	@Autowired
	BreedRepositorie breedRepository ;
	
	@Autowired
	CategorieRepositorie categorieRepositorie;
	
	@Autowired
	BreedPhotoRepositorie breedPhotoRepositorie;

	
	public void loadDataBase(){		
		categorieRepositorie.saveAll(processor.listCategorie());
		List<Breed> list = processor.listBreeds();
		list.forEach(breed->breed.setPhoto(processor.getBreedPhoto(breed, null)));
		breedRepository.saveAll(list);	
		String hatID [] ={"1"};
		breedPhotoRepositorie.saveAll(processor.getBreedPhoto(null, hatID));		
		String glassesID [] ={"4"};
		breedPhotoRepositorie.saveAll(processor.getBreedPhoto(null, glassesID));

	}
}
