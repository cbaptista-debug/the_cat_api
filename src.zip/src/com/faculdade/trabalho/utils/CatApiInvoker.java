package com.faculdade.trabalho.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.faculdade.trabalho.entities.Breed;

@Component
public class CatApiInvoker {

	@Autowired
	private Environment env;

	public String listBreeds() {
		HttpHeaders headers = new HttpHeaders();//		
		headers.set("x-api-key", env.getProperty("x-api-key"));
		return new RestTemplate().exchange(
											env.getProperty("cat.api.breed.list"), 
											HttpMethod.GET, 
											new HttpEntity<String>("parameters", headers),
															String.class).getBody();			
	}
	
	public String listCategories() {
//		HttpHeaders headers = new HttpHeaders();//		
//		headers.set("x-api-key", env.getProperty("x-api-key"));
//		return new RestTemplate().exchange(
//											env.getProperty("cat.api.breed.categories"), 
//											HttpMethod.GET, 
//											new HttpEntity<String>("parameters", headers),
//															String.class).getBody();
		
		String json = "[{\"id\":5,\"name\":\"boxes\"},{\"id\":6,\"name\":\"caturday\"},{\"id\":15,\"name\":\"clothes\"},{\"id\":9,\"name\":\"dream\"},{\"id\":3,\"name\":\"funny\"},{\"id\":1,\"name\":\"hats\"},{\"id\":10,\"name\":\"kittens\"},{\"id\":14,\"name\":\"sinks\"},{\"id\":2,\"name\":\"space\"},{\"id\":4,\"name\":\"sunglasses\"},{\"id\":7,\"name\":\"ties\"}]";
		return json; 
	}
	
	public String getBreedPhoto(Breed breed, String[] categoriesID) {
		HttpHeaders headers = new HttpHeaders();//		
		headers.set("x-api-key", env.getProperty("x-api-key"));
		UriComponentsBuilder b = UriComponentsBuilder.fromHttpUrl(env.getProperty("cat.api.breed.photo"));
		if(breed!=null)
			b.queryParam("breed", breed.getId());
		if(categoriesID!=null)
			b.queryParam("category_ids", String.join(",", categoriesID));
        b.queryParam("limit", "3");
		
		return new RestTemplate().exchange(b.toUriString(),HttpMethod.GET,new HttpEntity<String>("parameters", headers),String.class).getBody();			
	}


}
