package com.faculdade.trabalho.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.faculdade.trabalho.entities.Categorie;

@Repository
public interface CategorieRepositorie extends JpaRepository<Categorie, Integer>{
	


}
