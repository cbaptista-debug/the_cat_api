package com.faculdade.trabalho;


import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.faculdade.trabalho.utils.DataBaseLoader;

@SpringBootApplication
public class CatApiApplication {
/*Classe responsavel por invocar o main e realizar o post construct para o banco de dados h2 criado com o Maven */
	
	public static void main(String[] args) {
		SpringApplication.run(CatApiApplication.class, args);
	}

	@Autowired
	/* Loader do banco de dados */
	DataBaseLoader dataBaseLoader;

	
	@PostConstruct
    private void init() {
		dataBaseLoader.loadDataBase();

        
    }


}
