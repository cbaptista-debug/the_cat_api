package com.faculdade.trabalho.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.faculdade.trabalho.entities.Breed;
import com.faculdade.trabalho.entities.Photo;
import com.faculdade.trabalho.entities.Categorie;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CatApiProcessor {
	
	@Autowired
	private CatApiInvoker invoker;

	public List<Breed> listBreeds() {
		List<Breed> list = new ArrayList<Breed>();
		try {
			list = Arrays.asList(new ObjectMapper().readValue(invoker.listBreeds(), Breed[].class));
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	
	public List<Categorie> listCategorie() {
		List<Categorie> list = new ArrayList<Categorie>();
		try {
			list = Arrays.asList(new ObjectMapper().readValue(invoker.listCategories(), Categorie[].class));
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	
	
	
	public List<Photo> getBreedPhoto(Breed breed,String[] categorie) {
		List<Photo> list = new ArrayList<Photo>();
		try {
			String json =invoker.getBreedPhoto(breed, categorie);
			list = Arrays.asList(new ObjectMapper().readValue(json, Photo[].class));
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}
