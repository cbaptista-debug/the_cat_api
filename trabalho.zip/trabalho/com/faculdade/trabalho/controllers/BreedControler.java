package com.faculdade.trabalho.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.faculdade.trabalho.entities.Breed;
import com.faculdade.trabalho.entities.Photo;
import com.faculdade.trabalho.repositories.BreedPhotoRepositorie;
import com.faculdade.trabalho.repositories.BreedRepositorie;

@RestController
public class BreedControler {
	
	@Autowired
	BreedRepositorie repository;
	
	@Autowired
	BreedPhotoRepositorie photoRepository;
	
	
	@GetMapping("/listBreedNames")
	public List<String> listBreedNames() {
		return repository.listBreedNames();
	}
	
	@GetMapping("/listBreedCompletInfo")
	public List<Breed> listBreedCompletInfo() {
		return repository.findAll();
	}
	
	@GetMapping("/getBreedCompletInfo/Name/{name}")
	public List<Breed> getBreedCompletInfo(@PathVariable String name) {
		Breed b = new Breed();
		b.setName(name);	
		return repository.findAll(Example.of(b));
	}
	
	@GetMapping("/listBreedNames/Temperament/{temperament}")
	public List<String> listBreedNamesByTemperament(@PathVariable String temperament) {
		return repository.listBreedNamesByTemperament(temperament);
	}
	
	@GetMapping("/listBreedNames/Origin/{origin}")
	public List<String> listBreedNamesByOrigin(@PathVariable String origin) {
		return repository.listBreedNamesByOrigin(origin);
	}
	
	
	@GetMapping("/listBreedPhotos/{category_id}")
	public List<Photo> listBreedPhotos(@PathVariable Integer category_id) {
		return photoRepository.getBreedPhotosByCategories(category_id);
	}
	
	@GetMapping("/listBreedPhotos")
	public List<Photo> listBreedPhotos() {		
		return photoRepository.findAll();
	}


}
