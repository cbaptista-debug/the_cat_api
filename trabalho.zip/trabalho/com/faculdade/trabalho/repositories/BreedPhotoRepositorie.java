package com.faculdade.trabalho.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.faculdade.trabalho.entities.Photo;

@Repository
public interface BreedPhotoRepositorie extends JpaRepository<Photo, Integer>{
	
	@Query(value ="SELECT TOP 3 * FROM PHOTO INNER JOIN PHOTOS_CATEGORIES  ON PHOTO.ID_PHOTOPK =  PHOTOS_CATEGORIES.ID_PHOTO  WHERE ID_CATEGORIE  = ?1  ", nativeQuery = true)
	List<Photo> getBreedPhotosByCategories(Integer idCategorie);
}
